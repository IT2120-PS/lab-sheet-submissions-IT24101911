setwd("C:/Users/it24101911/Desktop/it24101911")
getwd()
data<-read.table("Data.txt",header =TRUE,sep=",")
fix(data)

##attach filr into R
attach(data)

##rename the variables of the data set
names(data)<-c("X1","X2")
attach(data)
##obtain histogtam for number of shareholders
hist(X2,main="Histogram for Number of Shareholders")

##part2
histogram<-hist(X2,main="Histogram for Number of Shareholders",breaks=seq(130,270,length=8),right=FALSE)
?hist

#Part 3
#PASSign class limits of the frequency distribution into a variable called "breaks"
breaks <-round(histogramSbreaks)

#Passion class frequencies of the histogram into a variable called "freg"
freq<-histogramScounts

##Assign mid point of each class into a variable called "mids"
mids<-histogramimids

##Creating the variable called "Classes" for the frequency distribution
classes<-c()

##Creating a "for" loop to assign classes of the frequency distribution into "Classes" variable crated above.
for(i in 1:length(breaks)-1){
  classes [i]<- paste0("[", breaks[i], ",", breaks [i+1],")")
}

##Obtaining frequency distribution by combining the values of "Classes" & "freq" variables
## "cbind" command used to merge the columns with same length
cbind(Classes= classes, Frequency= freq)


##Exercise
Delivery_Times<-read.table("Exercise – Lab 05.txt",header =TRUE,sep=",")
fix(Delivery_Times)

##qs2
# Extract the delivery times column (assuming it's named 'Time')
times <- Delivery_Times$Time  # Replace 'Time' with the actual column name if different

# Define breaks for 9 class intervals from 20 to 70
breaks <- seq(20, 70, length.out = 10)  # 9 intervals need 10 break points

# Create histogram with right-open intervals
hist(times, breaks = breaks, right = FALSE, 
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time",
     ylab = "Frequency",
     col = "skyblue",
     border = "white")

##qs3


