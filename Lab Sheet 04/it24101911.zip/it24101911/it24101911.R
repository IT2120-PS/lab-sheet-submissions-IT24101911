setwd("C:/Users/it24101911/Desktop/it24101911")
getwd()

##importing the data set
branch_data<-read.table("Exercise.txt",header=TRUE,sep=",")

##view the file in separate window
head(branch_data)
#check variable types
str(branch_data)



boxplot(branch_data$Sales_X1,main="Boxplot of Sales")

summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)



get.outliers <- function(z) {
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  outliers <- sort(z[z < lb | z > ub])
  print(paste("Outliers:", paste(outliers, collapse = ",")))
}

get.outliers(branch_data$Years_X3)
