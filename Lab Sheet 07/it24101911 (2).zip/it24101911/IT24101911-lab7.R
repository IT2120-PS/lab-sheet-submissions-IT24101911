setwd("C://Users//ASUS//OneDrive//Desktop///it24101911")
getwd()

# Q1: Train arrival time ~ Uniform(0,40)
# Probability that train arrives between 10 and 25 minutes
punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)
# Expected output: 0.375

# Q2: Software update time ~ Exponential(rate = 1/3)
# Probability that update takes at most 2 hours
pexp(2, rate = 1/3)
# Expected output: 0.4865829

# Q3: IQ scores ~ Normal(mean = 100, sd = 15)
# Probability that a person has IQ above 130
1 - pnorm(130, mean = 100, sd = 15)
# Expected output: 0.02275013

# Q4: IQ score at the 95th percentile
qnorm(0.95, mean = 100, sd = 15)
# Expected output: 124.6728
